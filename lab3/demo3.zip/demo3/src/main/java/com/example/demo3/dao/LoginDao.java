package com.example.demo3.dao;

public interface LoginDao {
    public boolean login(String uid, String pwd);
}
